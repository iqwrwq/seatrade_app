SeaTrade V 0.98 beta

Fehlerkorrekturen:
- sea.Cargo.java : der 2. Konstruktor übernimmt jetzt die Cargo-Id korrekt
- manuelle Cargo-Erzeugung (cargo n) in Admin-Konsole geht jetzt auch wieder bei LEVEL = 0
- fehlender Refresh der registrierten Company-Anzahl ergänzt.   